// Metadata for the INDUK (official) report — guru per kelas + penyelia per group.
// Kelas / tingkatan strings must exactly match data/students.js.

export const MAINSTREAM_SECTIONS = [
  {
    tingkatan: 'PERALIHAN',
    label: 'PERALIHAN',
    penyelia: 'En. Faizul',
    subgroups: [
      { label: null, kelasList: [
        { kelas: 'PERALIHAN', guru: 'Khatijah Binti Che Ngah' },
      ] },
    ],
  },
  {
    tingkatan: '1',
    label: 'TINGKATAN 1',
    penyelia: 'En. Faizul',
    subgroups: [
      { label: null, kelasList: [
        { kelas: '1 AMANAH', guru: 'Noor Shamila Binti Abdul Khadir' },
        { kelas: '1 BUDIMAN', guru: 'Ramani Yama A/P Apparao' },
        { kelas: '1 CERIA', guru: 'Noor Amirah Binti Rosli' },
        { kelas: '1 DINAMIK', guru: 'Banumathy A/P Muniandy' },
        { kelas: '1 EHSAN', guru: 'Nur Syamimi Binti Muhamed Bustaman' },
        { kelas: '1 FIKRAH', guru: 'Muhamad Zaki Bin Rajali @ Ghazali' },
        { kelas: '1 GIGIH', guru: 'Amirah Az Zahra Binti Ahmad Fuad' },
        { kelas: '1 HARMONI', guru: 'Gustina Binti Harun' },
        { kelas: '1 IKHLAS', guru: 'Nurmiati Binti Muhd. Nursyah' },
        { kelas: '1 JUJUR', guru: 'Siti Nurshafiqa Binti Aminudin' },
        { kelas: '1 KARISMA', guru: 'Muhammad Khirul Safiq Bin MD Said' },
      ] },
    ],
  },
  {
    tingkatan: '2',
    label: 'TINGKATAN 2',
    penyelia: 'Cik Norsyabina',
    subgroups: [
      { label: null, kelasList: [
        { kelas: '2 AMANAH', guru: 'Nurul Aina Binti Mohamad Zaini' },
        { kelas: '2 BUDIMAN', guru: 'Tang Soo Yee' },
        { kelas: '2 CERIA', guru: 'Nurul Izzah Binti Mat Sahak' },
        { kelas: '2 DINAMIK', guru: 'Shafinas Binti Ibrahim' },
        { kelas: '2 EHSAN', guru: 'Siti Haryati Binti Idris' },
        { kelas: '2 FIKRAH', guru: 'Ong Nyin San' },
        { kelas: '2 GIGIH', guru: 'Mohd Hafizul Bin Abu Hassan' },
        { kelas: '2 HARMONI', guru: 'Nur Amalina Binti Rahmad Syah' },
        { kelas: '2 IKHLAS', guru: 'Noor Shahirah Idayu Binti Hashim' },
        { kelas: '2 JUJUR', guru: 'Nur Fatin Aisyah Binti Abdul Rahim' },
      ] },
    ],
  },
  {
    tingkatan: '3',
    label: 'TINGKATAN 3',
    penyelia: 'Pn. Junainah',
    subgroups: [
      { label: null, kelasList: [
        { kelas: '3 AMANAH', guru: 'Mohd Fitri Bin Othman' },
        { kelas: '3 BUDIMAN', guru: 'Zuraida Bt Mat Desa' },
        { kelas: '3 CERIA', guru: 'Nor Adlina Binti Ali' },
        { kelas: '3 DINAMIK', guru: 'Ku Rohaida Binti Ku Shafie' },
        { kelas: '3 EHSAN', guru: 'Siti Khalijah Binti Abu Kassim' },
        { kelas: '3 FIKRAH', guru: 'Muthiah Valliyappah A/L Karuppiah' },
        { kelas: '3 GIGIH', guru: 'Mohd Saiful Bin Azmi' },
        { kelas: '3 HARMONI', guru: 'Siti Amira Binti Tajudin' },
        { kelas: '3 IKHLAS', guru: 'Muhammad Haniff Bin Roslam' },
        { kelas: '3 JUJUR', guru: 'Chandrasekaran A/L Ramasamy' },
      ] },
    ],
  },
  {
    tingkatan: '4',
    label: 'TINGKATAN 4',
    penyelia: 'Cik Adzlina A.',
    subgroups: [
      { label: 'STEM', kelasList: [
        { kelas: '4 STEM 1', guru: 'Mohd Faquan Bin Khalid' },
        { kelas: '4 STEM 2', guru: 'Syakriah Binti Ishak' },
        { kelas: '4 STEM 3', guru: 'Roslan Bin Hasan' },
      ] },
      { label: 'KM & PVMA', kelasList: [
        { kelas: '4 KM 1', guru: 'Mohamad Norain Bin Che Aad @ Che Saad' },
        { kelas: '4 KM 2', guru: 'Tamil Malar A/P Pachaiyapan' },
        { kelas: '4 KM 3', guru: 'Nur Azwa Binti Muhamad Yusof' },
        { kelas: '4 KM 4', guru: 'Noor Ainil Munirah Binti Faizol' },
        { kelas: '4 KM 5', guru: 'Noor Aribah Binti Mohd Yusoff' },
        { kelas: '4 KM 6', guru: 'Nurul Hafiza Binti Mustafa' },
        { kelas: '4 PVMA', guru: 'Nur Hamizah Binti Hamidon' },
      ] },
    ],
  },
  {
    tingkatan: '5',
    label: 'TINGKATAN 5',
    penyelia: 'Cik Ng Ai Pheng',
    subgroups: [
      { label: 'STEM', kelasList: [
        { kelas: '5 STEM 1', guru: 'Siti Salmah Binti Samsudin' },
        { kelas: '5 STEM 2', guru: 'Siti Darwishah Balqis Binti Rosle' },
        { kelas: '5 STEM 3', guru: 'Nur Zulaika Atiqah Binti Muhamad Zamani' },
      ] },
      { label: 'KM & PVMA', kelasList: [
        { kelas: '5 KM 1', guru: 'Nur Hidayah Binti Abd Rahman' },
        { kelas: '5 KM 2', guru: 'Lim Guat Ling' },
        { kelas: '5 KM 3', guru: 'Muhamad Arif Khairuddin Bin Abd Aziz' },
        { kelas: '5 KM 4', guru: 'Hamidah Binti Ibrahim' },
        { kelas: '5 KM 5', guru: 'Siti Norayu Binti Ismail' },
        { kelas: '5 KM 6', guru: 'Suryati Binti Ratim' },
        { kelas: '5 PVMA', guru: 'Ummi Umairoh Binti Othman' },
      ] },
    ],
  },
];

export const PPKI_SECTION = {
  tingkatan: 'PPKI',
  label: 'PPKI (PENDIDIKAN KHAS)',
  penyelia: 'Pn. Misrajah',
  subgroups: [
    { label: null, kelasList: [
      { kelas: 'KR TUNAS', guru: 'Nurul Azmira Bt. Mohd. Safiee' },
      { kelas: 'KR HARAPAN', guru: 'Sarinah Bt. Che Soh' },
      { kelas: 'KR AZAM', guru: 'Rohiza Bt Abdul Rashid' },
      { kelas: 'KR CEKAL', guru: 'Siti Annirah Binti Mohd Akhir' },
      { kelas: 'KSSM T1 CEMERLANG', guru: 'Ismaliza Binti Ismail' },
      { kelas: 'KSSM T2 GEMILANG', guru: 'Norhaslina Binti Ariffin' },
      { kelas: 'KSSM T5 WAWASAN', guru: 'Wan Ruzita Bt Wan Sulaiman' },
    ] },
  ],
};
